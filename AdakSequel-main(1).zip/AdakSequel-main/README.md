## Name
Adak

## Description
Welcome to Adak. Adak is a system that allows users to scan a QR code, and dependent on time presents an HTML page with a prompt for the user, and then sends out a teams notification, and opens a troubleticket on their behalf. 

## Authors and acknowledgment
Anthony Noel anthony.noel@colorado.edu

## License
Open Source GNU License

## Project status
Always in progress, building up as needed. 
